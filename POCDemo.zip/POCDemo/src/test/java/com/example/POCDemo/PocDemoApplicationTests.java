package com.example.POCDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
